<h2>Pendaftaran Berhasil!</h2>
<p>Terima kasih telah mendaftar. Data Anda telah berhasil disimpan.</p>

<a href="{{ url('/') }}">Kembali ke Beranda</a>
