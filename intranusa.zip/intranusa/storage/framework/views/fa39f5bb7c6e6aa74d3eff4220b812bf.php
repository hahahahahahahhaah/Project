<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Boxicons -->
    <link href="https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css" rel="stylesheet">

    <!-- My CSS -->
    <link rel="stylesheet" href="/style2.css">
    <link rel="stylesheet" href="/admin.css">

    <!-- Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">

    <!-- jsPDF untuk generasi PDF -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>

    <!-- JS SCRIPT -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>

    <title>From Admin - Data Survey</title>

    <!-- Favicon -->
    <link href="<?php echo e(asset('img/jjj.jpg')); ?>" rel="icon">
    <link href="<?php echo e(asset('img/jjj.jpg')); ?>" rel="apple-touch-icon">

    <?php echo $__env->yieldPushContent('styles'); ?> <!-- Untuk menambahkan style tambahan di halaman tertentu -->
    <?php echo $__env->yieldPushContent('scripts'); ?> <!-- Untuk menambahkan script tambahan di halaman tertentu -->
</head>


<body class="light-theme">
    <!-- SIDEBAR -->
    <section id="sidebar">
        <a href="#" class="brand">
           <i class='bx bx-wifi' ></i>
            <span class="text">Intranusa</span>
        </a>
        <ul class="side-menu top">
            <li>
                <a href="dashboard">
                    <i class='bx bxs-dashboard'></i>
                    <span class="text">Dashboard</span>
                </a>
            </li>
            <li>
                <a href="data">
                    <i class='bx bxs-group'></i>
                    <span class="text">Data Berlangganan</span>
                </a>
            </li>
            <li class="active">
                <a href="survei">
                    <i class='bx bxs-message-dots'></i>
                    <span class="text">Data survey</span>
                </a>
            </li>
        </ul>
        <ul class="side-menu">
            <li>
                <a class="logout" href="#" data-bs-toggle="modal" data-bs-target="#logoutModal">
                    <i class='bx bxs-log-out-circle'></i>
                    <span class="text">Logout</span>
                </a>

            </li>
        </ul>

        <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ready to leave?</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Pilih "Keluar" di bawah jika Anda siap untuk mengakhiri sesi Anda saat ini.
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <a class="btn btn-primary" href="logout.php">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- SIDEBAR -->



    <!-- CONTENT -->
    <section id="content">
        <!-- NAVBAR -->
        <nav>
            <i class='bx bx-menu'></i>

            <div class="notification-icon" style="position: relative; display: inline-block; left: 93%; margin-right: 20px;">
                <a href="notification.php">
                    <i class="bx bxs-bell" style="font-size: 24px;"></i> <!-- Lonceng -->

                    <span class="badge" style="position: absolute; top: -5px; right: -5px; background-color: red; color: white; border-radius: 50%; padding: 4px 8px; font-size: 12px;">

                    </span>

                </a>
                <audio id="notificationSound" src="path/to/your/notification-sound.mp3" preload="auto"></audio>

            </div>
        </nav>
        <div class="card mt-3">
            <div class="card-header bg-primary text-white">
                Survey kepuasan pelanggan
            </div>
            <div class="container">
                <div class="row mb-3">
                    <!-- Tombol "Tambah Data" di sisi kiri -->
                    <div class="col-md-2 mb-2">
                        <button type="button" class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#modalTambah"
                            data-bs-target="#staticBackdrop"><i class="bi bi-plus"></i>
                            Tambah data
                        </button>
                    </div>
                    <div class="col-md-10">
                        <form id="filter-form">
                            <div class="filter-container">
                                <!-- Filter by Date -->
                                <div class="filter-group">
                                    <label for="date">Pertanggal:</label>
                                    <input type="date" name="date" class="form-control">
                                </div>

                                <!-- Filter by Month -->
                                <div class="filter-group">
                                    <label for="month">Perbulan:</label>
                                    <input type="month" name="month" class="form-control">
                                </div>
                                <!-- Filter by Day of the Week -->
                                <div class="filter-group">
                                    <label for="day_of_week">Perhari:</label>
                                    <select name="day_of_week" class="form-control">
                                        <option value="">Select Day</option>
                                        <option value="1">Sunday</option>
                                        <option value="2">Monday</option>
                                        <option value="3">Tuesday</option>
                                        <option value="4">Wednesday</option>
                                        <option value="5">Thursday</option>
                                        <option value="6">Friday</option>
                                        <option value="7">Saturday</option>
                                    </select>
                                </div>
                                <!-- Button group di sebelah kanan -->
                                <div class="button-group">
                                    <button type="submit" class="btn btn-primary">Filter</button>
                                     <a href="survei.php" class="btn btn-danger">Reset</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover cihuy">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama dan alamat pelanggan</th>
                            <th>Email</th>
                            <th>Kualitas internet</th>
                            <th>Customer service</th>
                            <th>Teknisi</th>
                            <th>Gangguan</th>
                            <th>Kecepatan</th>
                            <th>Kualitas harga</th>
                            <th>Rekomendasi</th>
                            <th>Komentar</th>
                            <th>Created at</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>

                    <tbody>

                    </tbody>
                </table>
                <div class="d-flex justify-content-left mt-4">
                    <button class="btn btn-success" type="button" id="downloadButtonId" style="margin-left: 20px;" onclick="generatePDF()">
                        <i class="bi bi-download"></i> Download as PDF
                    </button>
                    <button id="previewButtonId" class="btn btn-info" style="margin-left: 40px;">
                        <i class="bi bi-eye"></i> View PDF
                    </button>
                    <div aria-label="Page navigation" style="margin-left: 40px;">
                        <ul class="pagination" id="pagination">

                        </ul>
                    </div>
                </div>

                <!-- Modal untuk preview PDF -->
                <div class="modal fade" id="pdfPreviewModal" tabindex="-1" aria-labelledby="pdfPreviewModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="pdfPreviewModalLabel">Preview PDF</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <iframe id="pdfPreviewIframe" width="100%" height="500px"></iframe>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>




                <!-- start modal tambah -->
                <div class="modal fade" id="modalTambah" data-bs-keyboard="false"
                    tabindex="-1" aria-LabeLLedby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">Form Data Pelanggan</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form method="POST" id="formTambahData">
                                <input type="hidden" name="id" value="">
                                <div class="modal-body">

                                    <div class="form-group">
                                        <label class="form-label">Nama dan alamat Pelanggan</label>
                                        <input type="text" class="form-control" name="tnama"
                                            placeholder="Masukkan Nama dan alamat lengkap" required>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label">Email</label>
                                        <input type="text" class="form-control" name="email"
                                            placeholder="Masukkan alamat email anda.." required>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label">Kualitas internet</label>
                                        <select class="form-control" name="tkualitas" required>
                                            <option></option>
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                            <option value="4">4</option>
                                            <option value="5">5</option>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label">Customer service</label>
                                        <select class="form-control" name="tservice" required>
                                            <option></option>
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                            <option value="4">4</option>
                                            <option value="5">5</option>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label">Teknisi</label>
                                        <select class="form-control" name="tteknisi" required>
                                            <option></option>
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                            <option value="4">4</option>
                                            <option value="5">5</option>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label">Gangguan</label>
                                        <select class="form-control" name="tgangguan" required>
                                            <option></option>
                                            <option value="Tidak pernah">Tidak pernah</option>
                                            <option value="Jarang">Jarang</option>
                                            <option value="Kadang-kadang">Kadang-kadang</option>
                                            <option value="Sering">Sering</option>
                                            <option value="Sangat sering">Sangat sering</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Kecepatan</label>
                                        <select class="form-control" name="tkecepatan" required>
                                            <option></option>
                                            <option value="Sangat sesuai">Sangat sesuai</option>
                                            <option value="Sesuai">Sesuai</option>
                                            <option value="Cukup sesuai">Cukup sesuai</option>
                                            <option value="Tidak sesuai">Tidak sesuai</option>
                                        </select>

                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Kualitas harga</label>
                                        <select class="form-control" name="tharga" required>
                                            <option></option>
                                            <option value="Ya, sebanding">Ya, sebanding</option>
                                            <option value="Tidak, tidak sebanding">Tidak, tidak sebanding</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Rekomendasi</label>
                                        <select class="form-control" name="trekomendasi" required>
                                            <option></option>
                                            <option value="Sangat mungkin">Sangat mungkin</option>
                                            <option value="Mungkin">Mungkin</option>
                                            <option value="Tidak mungkin">Tidak mungkin</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Komentar</label>
                                        <textarea class="form-control" name="tkomentar" rows="3" required></textarea>
                                    </div>

                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Keluar</button>
                                </div>
                            </form>
                        </div>
                        <!-- finish modal tambah -->
                    </div>
                    
</body>

</html>

<?php /**PATH C:\laragon\www\Joks_Laravel\intranusa\resources\views/admin/survei.blade.php ENDPATH**/ ?>