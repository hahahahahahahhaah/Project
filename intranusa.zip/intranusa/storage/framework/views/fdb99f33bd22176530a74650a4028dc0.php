<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Boxicons -->
    <link href="https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css" rel="stylesheet">

    <!-- My Custom CSS -->
    <link rel="stylesheet" href="/style2.css">
    <link rel="stylesheet" href="/admin.css">

    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Bootstrap JS (Bundle with Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

    <title>Form Admin</title>
    <link href="<?php echo e(asset('img/jjj.jpg')); ?>" rel="icon">
    <link href="<?php echo e(asset('img/jjj.jpg')); ?>" rel="apple-touch-icon">
</head>


<body>
    <section id="sidebar">
        <a href="#" class="brand">
            <i class='bx bx-wifi' ></i>
            <span class="text">Intranusa</span>
        </a>
        <ul class="side-menu top">
            <li class="active">
                <a href="dashboard">
                    <i class='bx bxs-dashboard' ></i>
                    <span class="text">Dashboard</span>
                </a>
            </li>
            <li>
                <a href="data">
                    <i class='bx bxs-group' ></i>
                    <span class="text">Data Berlangganan</span>
                </a>
            </li>
            <li>
                <a href="survei">
                    <i class='bx bxs-message-dots' ></i>
                    <span class="text">Data survey</span>
                </a>
            </li>
        </ul>
        <ul class="side-menu">
    <li>
    <a class="logout" href="#" data-bs-toggle="modal" data-bs-target="#logoutModal">
    <i class='bx bxs-log-out-circle'></i>
    <span class="text">Logout</span>
</a>

    </li>
</ul>


</section>

<section id="content">
    <div class="notif-container"></div>
        <!-- NAVBAR -->
        <nav>
            <button class="menu-toggle" id="menuToggle">
                <i class='bx bx-menu'></i>
            </button>
            <div class="notification-icon" style="position: relative; display: inline-block; left: 93%; margin-right: 20px;">
    <a href="notification.php">
        <i class="bx bxs-bell" style="font-size: 24px;"></i> <!-- Lonceng -->
            <span class="badge" style="position: absolute; top: -5px; right: -5px; background-color: red; color: white; border-radius: 50%; padding: 4px 8px; font-size: 12px;">
            </span>
    </a>
    <audio id="notificationSound" src="path/to/your/notification-sound.mp3" preload="auto"></audio>

</div>


        </nav>
        <!-- NAVBAR -->

        <!-- MAIN -->
        <main>
            <div class="head-title">
                <div class="left">
                    <h1>Dashboard admin</h1>
                    <ul class="breadcrumb">

                    </ul>
                </div>

            </div>

            <ul class="box-info">
    <li>
        <i class='bx bxs-calendar-check'></i>
        <span class="text">
            <h3 id="total-survey"></h3> <!-- Menampilkan total survey -->
            <p>Survey</p>
        </span>
    </li>
    <li>
        <i class='bx bxs-group'></i>
        <span class="text">

            <h3  id="total-pelanggan"><?php echo e($totalPelanggan); ?></h3> <!-- Menampilkan total pelanggan -->
            <p>Pelanggan</p>
        </span>
    </li>
</ul>

<div class="clearfix">
<div class="table-data">
    <div class="order">
        <div class="head">
            <h3>Berlangganan</h3>
            <i class='bx bx-filter'></i>
             <i class='bx bxs-data'></i>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Nama Pelanggan</th>
                    <th>Email</th>
                    <th>Paket</th>
                    <th>Lokasi Pemasangan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    
                    <td><?php echo e($data->nama_pelanggan); ?></td>
                    <td><?php echo e($data->email); ?></td>
                    <td><?php echo e($data->paket); ?></td>
                    <td><?php echo e($data->lokasi_pemasangan); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </tbody>
                   </table>
                  <div class="pagination d-flex justify-content-left mt-4" style="margin-left: 75%;">
                   <a href="" class="btn btn-secondary me-2">
                       <i class="fas fa-arrow-left" style="margin-top: 5px;"></i>
                   </a>

               <span class="btn btn-light"></span>

                   <a href="" class="btn btn-secondary ms-5">
                       <i class="fas fa-arrow-right" style=" margin-top: 5px;"></i>
                   </a>
           </div>


               </div>
           </div>
<div class="todo">
    <div class="head">
        <h3>Survey</h3>
        <i class='bx bx-filter'></i>
        <i class='bx bxs-color'></i>
    </div>
    <ul class="todo-list">

        <!-- Menampilkan persentase dengan kolom warna (progress bar) -->




    </ul>
</div>



        </main>
        <!-- MAIN -->
    </section>
</body>

</html>
<?php /**PATH C:\laragon\www\Joks_Laravel\intranusa\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>